$(start);

function start(){
    $("#Login").on("click", show);
}

function show(){
    let myInputVal = $("#Login")
    $("#AmountInAccount").load(`bank.php?moneyHave=${myInputVal}`);

    In = $("<input>");
    In.attr("id", "InputId");
    $("#NextActions").append(In);

    Depbtn = $("<button>Deposit amount</button>");
    Depbtn.attr("id", "DepositId");
    $("#NextActions").append(Depbtn);
    Depbtn.on("click", Deposit);

    Drawbtn = $("<button>Widthdraw amount</button>");
    Drawbtn.attr("id", "DrawbtnId");
    $("#NextActions").append(Drawbtn);
    Drawbtn.on("click", Widthdraw);
}

function Deposit(){

}

function Widthdraw(){

}